# Ethereum Arbitrage Bot Dashboard
A React dashboard for monitoring and controlling an Ethereum arbitrage bot smart contract.
